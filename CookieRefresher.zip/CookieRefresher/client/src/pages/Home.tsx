import BackgroundCanvas from "../components/BackgroundCanvas";
import Title from "../components/Title";

export default function Home() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black">
      <BackgroundCanvas />
      <Title />
    </div>
  );
}
