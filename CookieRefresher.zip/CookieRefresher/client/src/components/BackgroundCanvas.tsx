import { useEffect, useRef } from "react";

interface Dot {
  x: number;
  y: number;
  size: number;
  speed: number;
}

export default function BackgroundCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dotsRef = useRef<Dot[]>([]);
  const animationSpeed = 0.4;
  const maxDotSize = 5;
  const dotDensity = 0.5; // Reduced density for better performance
  const requestRef = useRef<number>();
  const isRunningRef = useRef<boolean>(true); // Track if animation should run

  // Generate random dots based on screen size
  const generateDots = (width: number, height: number) => {
    const area = width * height;
    const dotCount = Math.floor(area * dotDensity / 1000);
    
    const newDots: Dot[] = [];
    for (let i = 0; i < dotCount; i++) {
      newDots.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * maxDotSize + 1,
        speed: Math.random() * 0.5 + 0.2 // Varying speeds for parallax effect
      });
    }
    dotsRef.current = newDots;
  };

  const animateCanvas = () => {
    // Only run animation if we're supposed to be running
    if (!isRunningRef.current) {
      requestRef.current = requestAnimationFrame(animateCanvas);
      return;
    }
    
    const canvas = canvasRef.current;
    if (!canvas) {
      requestRef.current = requestAnimationFrame(animateCanvas);
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      requestRef.current = requestAnimationFrame(animateCanvas);
      return;
    }

    // Clear with black background
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Set dot color
    ctx.fillStyle = '#FFFFFF';
    
    // Only animate and draw dots that are visible
    const dots = dotsRef.current;
    const canvasHeight = canvas.height;
    const canvasWidth = canvas.width;
    
    // Use a for loop instead of map for better performance
    for (let i = 0; i < dots.length; i++) {
      const dot = dots[i];
      
      // Draw the dot
      ctx.beginPath();
      ctx.arc(dot.x, dot.y, dot.size / 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Move the dot
      dot.y -= dot.speed * animationSpeed;
      
      // Reset position when dot goes off screen
      if (dot.y < -maxDotSize) {
        dot.y = canvasHeight + maxDotSize;
        dot.x = Math.random() * canvasWidth;
      }
    }
    
    // Continue animation loop with throttling
    requestRef.current = requestAnimationFrame(animateCanvas);
  };

  // Setup canvas and animation with page visibility handling
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set initial canvas dimensions
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    // Generate the initial dots
    generateDots(canvas.width, canvas.height);
    
    // Handle window resize
    const handleResize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      generateDots(canvas.width, canvas.height);
    };
    
    // Handle visibility change to save resources
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Page is not visible, pause animation
        isRunningRef.current = false;
        console.log('Animation paused - page not visible');
      } else {
        // Page is visible again, resume animation
        isRunningRef.current = true;
        console.log('Animation resumed - page visible');
      }
    };
    
    // Start animation loop
    requestRef.current = requestAnimationFrame(animateCanvas);
    
    // Add event listeners
    window.addEventListener('resize', handleResize);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Throttled resize listener to prevent excessive regeneration
    let resizeTimeout: number;
    const throttledResize = () => {
      if (resizeTimeout) {
        clearTimeout(resizeTimeout);
      }
      resizeTimeout = window.setTimeout(handleResize, 200);
    };
    
    window.addEventListener('resize', throttledResize);
    
    // Cleanup all event listeners and animation
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('resize', throttledResize);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      
      // Stop animation
      isRunningRef.current = false;
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute top-0 left-0 w-full h-full z-0"
    />
  );
}
