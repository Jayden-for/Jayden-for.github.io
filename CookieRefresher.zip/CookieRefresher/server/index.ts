import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

// Set up global uncaught exception handler
process.on("uncaughtException", (err) => {
  console.error("Uncaught exception:", err);
  // Don't exit the process, just log the error
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
  // Don't exit the process, just log the error
});

// Safety net to prevent memory leaks by monitoring memory
const MEMORY_CHECK_INTERVAL = 15 * 60 * 1000; // Check every 15 minutes
setInterval(() => {
  const memoryUsage = process.memoryUsage();
  // If RSS (Resident Set Size) is over 500MB, log a warning
  if (memoryUsage.rss > 500 * 1024 * 1024) {
    console.warn('High memory usage detected:', Math.round(memoryUsage.rss / 1024 / 1024) + 'MB');
    global.gc && global.gc(); // Try to run garbage collection if available
  }
}, MEMORY_CHECK_INTERVAL);

// Keep-alive checker
setInterval(() => {
  console.log("Server health check: OK");
}, 5 * 60 * 1000); // Every 5 minutes

const app = express();

// enable JSON parsing with larger size limits and more robust error handling
app.use(express.json({ 
  limit: '1mb',
  strict: true
}));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

// Request timeout handling
app.use((req, res, next) => {
  // Set a timeout for all requests
  req.setTimeout(30000, () => {
    console.error(`Request timeout for ${req.method} ${req.url}`);
  });
  next();
});

// Detailed logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  // Handle response errors
  res.on('error', (err) => {
    console.error('Response error:', err);
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    // Log the error but don't throw it
    console.error(`Error handling request ${req.method} ${req.url}:`, err);
    
    // Send appropriate response to the client
    res.status(status).json({ 
      message,
      // Include stack trace only in development
      stack: app.get("env") === "development" ? err.stack : undefined
    });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Try to use port 5000 first, then fall back to other available ports
  const findAvailablePort = async (startPort: number): Promise<number> => {
    const net = await import('net');
    
    return new Promise((resolve) => {
      const server = net.createServer();
      
      server.on('error', () => {
        resolve(findAvailablePort(startPort + 1));
      });
      
      server.listen(startPort, '0.0.0.0', () => {
        server.close(() => resolve(startPort));
      });
    });
  };

  const port = await findAvailablePort(5000);
  
  const startServer = async (port: number, retryCount = 0) => {
    const MAX_RETRIES = 5;
    try {
      await new Promise((resolve, reject) => {
        // Set up server with error handling
        const serverInstance = server.listen({
          port,
          host: "0.0.0.0",
          reusePort: true,
        }, () => {
          log(`serving on port ${port}`);
          
          // Add server error handler to recover from crashes
          serverInstance.on('error', (err) => {
            console.error('Server error:', err);
            // Don't shut down on error, try to keep running
          });
          
          resolve(true);
        }).on('error', (err: any) => {
          if (err.code === 'EADDRINUSE') {
            log(`Port ${port} is in use, trying next port...`);
            findAvailablePort(port + 1)
              .then(newPort => startServer(newPort))
              .then(resolve)
              .catch(reject);
          } else {
            reject(err);
          }
        });
      });
    } catch (error) {
      log(`Failed to start server: ${error}`);
      
      if (retryCount < MAX_RETRIES) {
        const retryDelay = Math.pow(2, retryCount) * 1000; // Exponential backoff
        log(`Retrying server startup in ${retryDelay/1000} seconds... (attempt ${retryCount + 1}/${MAX_RETRIES})`);
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        return startServer(port, retryCount + 1);
      } else {
        log(`Maximum retry attempts (${MAX_RETRIES}) reached. Server startup failed.`);
        // Instead of exiting, we'll keep the process running but log the failure
        console.error('Server failed to start after multiple attempts. Check logs for details.');
      }
    }
  };

  await startServer(port);
})();
