import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

// Dynamically import the refresh.js functions
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const refreshPath = path.join(__dirname, '..', 'attached_assets', 'refresh.js');

// Define the types for our imported functions
type GenerateAuthTicketFn = (roblosecurityCookie: string, useIPBypass?: boolean) => Promise<string>;
type RedeemAuthTicketFn = (authTicket: string) => Promise<{success: boolean, refreshedCookie?: string, error?: string}>;
type FetchSessionCSRFTokenFn = (roblosecurityCookie: string, useIPBypass?: boolean) => Promise<string | null>;

// Define empty functions initially
let generateAuthTicket: GenerateAuthTicketFn = async () => "Failed to load function";
let redeemAuthTicket: RedeemAuthTicketFn = async () => ({ success: false, error: "Failed to load function" });
let fetchSessionCSRFToken: FetchSessionCSRFTokenFn = async () => null;

// Try to load the functions dynamically with retry mechanism
const MAX_IMPORT_RETRIES = 3;

async function loadRefreshFunctions(retryCount = 0) {
  try {
    const refreshModule = await import(`../attached_assets/refresh.js`);
    generateAuthTicket = refreshModule.generateAuthTicket;
    redeemAuthTicket = refreshModule.redeemAuthTicket;
    fetchSessionCSRFToken = refreshModule.fetchSessionCSRFToken;
    console.log("Successfully loaded refresh.js functions");
    return true;
  } catch (error) {
    console.error(`Failed to load refresh.js (attempt ${retryCount + 1}/${MAX_IMPORT_RETRIES}):`, error);
    
    if (retryCount < MAX_IMPORT_RETRIES - 1) {
      // Wait before retrying with exponential backoff
      const delay = Math.pow(2, retryCount) * 1000;
      console.log(`Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return loadRefreshFunctions(retryCount + 1);
    }
    
    console.error("All attempts to load refresh.js failed");
    return false;
  }
}

// Load functions immediately
await loadRefreshFunctions();

const COOLDOWN_SECONDS = 30; // 30 seconds cooldown between refreshes
const MAX_ATTEMPTS = 4; // Maximum number of attempts for cookie refreshing
const lastRefreshTimes = new Map<string, number>();

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Cookie refresher API endpoints
  app.post("/api/refresh-cookie", async (req: Request, res: Response) => {
    const { cookie } = req.body;

    if (!cookie) {
      return res.status(400).json({ error: 'Cookie required' });
    }

    // Check cooldown
    const lastRefresh = lastRefreshTimes.get(cookie);
    const now = Date.now();
    if (lastRefresh) {
      const timeElapsed = (now - lastRefresh) / 1000;
      if (timeElapsed < COOLDOWN_SECONDS) {
        return res.status(429).json({ 
          error: `Please wait ${Math.ceil(COOLDOWN_SECONDS - timeElapsed)} seconds before refreshing again` 
        });
      }
    }

    try {
      const axiosInstance = axios.create({
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          Cookie: `.ROBLOSECURITY=${cookie}`
        }
      });

      // First attempt to get CSRF token
      const csrfResponse = await axiosInstance.post('https://auth.roblox.com/v2/logout', {}, {
        validateStatus: function (status) {
          return status === 403; // Expecting 403 with x-csrf-token
        }
      });

      const csrfToken = csrfResponse.headers['x-csrf-token'];

      if (!csrfToken) {
        return res.status(401).json({ error: 'Failed to obtain CSRF token' });
      }


      try {
        // Enable IP bypass for cookie refresh
        const authTicket = await generateAuthTicket(cookie, true);

        if (authTicket === "EXPIRED") {
          return res.status(401).json({ error: "Cookie expired", status: "EXPIRED" });
        }

        if (authTicket === "Failed to fetch auth ticket") {
          return res.status(400).json({ error: "Invalid cookie" });
        }

        const redemptionResult = await redeemAuthTicket(authTicket);

        if (!redemptionResult.success) {
          console.error('Redemption failed:', redemptionResult.error || 'Unknown error');
          return res.status(400).json({ error: redemptionResult.error || "Failed to refresh cookie" });
        }

        // Logout the old cookie
        try {
          await axios.post('https://auth.roblox.com/v2/logout', {}, {
            headers: {
              'Cookie': `.ROBLOSECURITY=${cookie}`,
              'x-csrf-token': csrfToken
            }
          });
        } catch (error: any) {
          console.log('Old cookie logout attempt:', error.message);
        }

        // Log success information for debugging
        console.log('Cookie refresh successful');

        lastRefreshTimes.set(cookie, now); // Update cooldown

        // Return the cookie to the client
        return res.json({ 
          success: true,
          newCookie: redemptionResult.refreshedCookie,
          message: 'Cookie refreshed successfully and old cookie expired'
        });
      } catch (error: any) {
        console.error('Error refreshing cookie:', error);
        const errorMessage = error.response?.data?.message || error.message;
        return res.status(500).json({ error: errorMessage });
      }
    } catch (error: any) {
      console.error('Error refreshing cookie:', error);
      const errorMessage = error.response?.data?.message || error.message;
      return res.status(500).json({ error: errorMessage });
    }
  });

  // API endpoint to get account info
  app.post("/api/account-info", async (req: Request, res: Response) => {
    const { cookie } = req.body;

    if (!cookie) {
      return res.status(400).json({ error: 'Cookie required' });
    }

    try {
      console.log("Getting account info with IP bypass...");
      
      // Get CSRF token with IP bypass
      const csrfToken = await fetchSessionCSRFToken(cookie, true);
      
      if (!csrfToken) {
        return res.status(401).json({ error: 'Failed to obtain CSRF token for account info' });
      }
      
      // Generate random IP for bypass
      const randomIp = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
      const randomClientId = Math.random().toString(36).substring(2, 15);
      
      // Set up headers similar to those in refresh.js
      const headers = {
        'x-csrf-token': csrfToken,
        'referer': 'https://www.roblox.com',
        'Content-Type': 'application/json',
        'Cookie': `.ROBLOSECURITY=${cookie}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': `en-US,en;q=${Math.random().toFixed(1)}`,
        'Cache-Control': 'no-cache',
        'Pragma': `no-cache-${randomClientId}`,
        'X-Forwarded-For': randomIp,
        'X-Real-IP': randomIp,
        'Connection': Math.random() > 0.5 ? 'keep-alive' : 'close',
        'Viewport-Width': (800 + Math.floor(Math.random() * 1000)).toString()
      };
      
      console.log(`Account info request using IP bypass: ${randomIp}`);
      
      // Make authenticated request with the bypass headers
      const userResponse = await axios.get('https://users.roblox.com/v1/users/authenticated', {
        headers,
        allowAbsoluteUrls: true
      });
      
      const userId = userResponse.data.id;
      console.log(`Successfully got user ID: ${userId}`);

      // Use same headers for additional requests
      const userInfo = await axios.get(`https://users.roblox.com/v1/users/${userId}`, {
        headers,
        allowAbsoluteUrls: true
      });
      const createdDate = new Date(userInfo.data.created);
      const nowDate = new Date();
      const millisecondsDiff = nowDate.getTime() - createdDate.getTime();
      const accountAge = Math.floor(millisecondsDiff / (1000 * 60 * 60 * 24 * 365));

      // For demonstration purposes
      const gamepasses = {
        MM2: 'Unknown',
        PS99: 'Unknown',
        AdoptMe: 'Unknown'
      };

      const robuxData = { pendingRobux: 'N/A', currentRobux: 'N/A' };
      const description = userInfo.data.description || 'No description available';

      return res.json({
        accountAge: `${accountAge} years`,
        gamepasses,
        summary: description,
        robux: robuxData,
      });
    } catch (error: any) {
      console.error('Error getting account info:', error);
      return res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}